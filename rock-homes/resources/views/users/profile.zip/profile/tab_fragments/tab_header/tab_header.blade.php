<div class="user-profile-nav">
  <ul class="nav nav-tabs" role="tablist">
      <div class="flex-row-reverse d-flex">
        <li class="nav-item">
            <a class="nav-link" id="timeline-tab" data-toggle="tab" href="#timeline" role="tab" aria-controls="timeline" aria-selected="false">Timeline</a>
        </li>

        <li class="nav-item">
            <a class="nav-link" id="about-tab" data-toggle="tab" href="#about" role="tab" aria-controls="about" aria-selected="false">About</a>
        </li>

        <li class="nav-item">
            <a class="nav-link" id="friends-tab" data-toggle="tab" href="#friends" role="tab" aria-controls="friends" aria-selected="false">Friends</a>
        </li>

        <li class="nav-item">
            <a class="nav-link active" id="settings-tab" data-toggle="tab" href="#settings" role="tab" aria-controls="settings" aria-selected="true">Settings</a>
        </li>
      </div>
  </ul>
  
</div>